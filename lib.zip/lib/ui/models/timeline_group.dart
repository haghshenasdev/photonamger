import 'media_item.dart';

class TimelineGroup {

  String title;

  DateTime start;

  DateTime end;

  List<MediaItem> items;

  TimelineGroup({
    required this.title,
    required this.start,
    required this.end,
    required this.items,
  });
}