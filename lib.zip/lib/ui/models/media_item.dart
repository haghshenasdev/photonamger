class MediaItem {
  final String path;

  final DateTime createdAt;

  final bool isVideo;
  bool isSelected;

  String get fileName {
    return path.split('\\').last;
  }

  MediaItem({
    required this.path,
    required this.createdAt,
    required this.isVideo,
    this.isSelected = true,
  });
}
