import 'media_item.dart';

class DuplicateGroup {
  final List<MediaItem> items;

  int selectedIndex;

  DuplicateGroup({required this.items, this.selectedIndex = 0});

  MediaItem get primary => items[selectedIndex];
}
