import 'package:fluent_ui/fluent_ui.dart';

class ApplyBar extends StatelessWidget {
  final VoidCallback onApply;

  final int mediaItems_length;
  final bool isAnalyzing;
  final String analyzeStatus;
  final double analyzeProgress;

  const ApplyBar({
    super.key,
    required this.onApply,
    required this.mediaItems_length,
    required this.isAnalyzing,
    required this.analyzeStatus,
    required this.analyzeProgress,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          if (isAnalyzing)
            Row(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8),

                  child: Row(
                    spacing: 10,
                    children: [
                      Text(analyzeStatus),

                      const SizedBox(height: 8),

                      ProgressBar(value: analyzeProgress * 100),

                      const SizedBox(height: 5),

                      Text('${(analyzeProgress * 100).toStringAsFixed(0)} %'),
                    ],
                  ),
                ),
              ],
            ),

          Padding(
            padding: const EdgeInsets.all(8),
            child: Text('تعداد فایل ها: ${mediaItems_length}'),
          ),
          const Expanded(
            child: Text("پس از بررسی دسته‌بندی‌ها، روی اعمال کلیک کنید."),
          ),

          FilledButton(onPressed: onApply, child: const Text("اعمال")),
        ],
      ),
    );
  }
}
