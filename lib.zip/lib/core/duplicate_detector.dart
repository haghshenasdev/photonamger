import 'dart:io';

import 'dart:math' as math;

import 'package:image/image.dart' as img;

import '../ui/models/duplicate_group.dart';

import '../ui/models/media_item.dart';

class DuplicateDetector {
  Future<List<DuplicateGroup>> findDuplicates(
    List<MediaItem> items, {

    Function(int current, int total, String status)? onProgress,
  }) async {
    final hashes = <MediaItem, BigInt>{};

    int currentHash = 0;

    for (final item in items) {
      currentHash++;

      onProgress?.call(
        currentHash,

        items.length,

        'در حال محاسبه هش تصاویر ($currentHash از ${items.length})',
      );

      if (item.isVideo) {
        continue;
      }

      final hash = await _pHash(item.path);

      if (hash != null) {
        hashes[item] = hash;
      }
    }

    onProgress?.call(0, hashes.length, 'در حال مقایسه تصاویر...');

    final groups = <DuplicateGroup>[];

    final visited = <MediaItem>{};

    const threshold = 8;

    int compareIndex = 0;

    for (final item in hashes.keys) {
      compareIndex++;

      onProgress?.call(
        compareIndex,

        hashes.length,

        'در حال مقایسه تصاویر ($compareIndex از ${hashes.length})',
      );

      if (visited.contains(item)) {
        continue;
      }

      final currentGroup = <MediaItem>[item];

      for (final other in hashes.keys) {
        if (item == other) {
          continue;
        }

        final distance = _hammingDistance(hashes[item]!, hashes[other]!);

        if (distance <= threshold) {
          currentGroup.add(other);

          visited.add(other);
        }
      }

      if (currentGroup.length > 1) {
        groups.add(DuplicateGroup(items: currentGroup));
      }
    }

    onProgress?.call(100, 100, 'تشخیص تصاویر تکراری به پایان رسید');

    return groups;
  }

  Future<BigInt?> _pHash(String path) async {
    try {
      final bytes = await File(path).readAsBytes();

      final image = img.decodeImage(bytes);

      if (image == null) {
        return null;
      }

      final resized = img.copyResize(image, width: 32, height: 32);

      final gray = img.grayscale(resized);

      final matrix = List.generate(32, (_) => List.filled(32, 0.0));

      for (int y = 0; y < 32; y++) {
        for (int x = 0; x < 32; x++) {
          matrix[y][x] = gray.getPixel(x, y).r.toDouble();
        }
      }

      final dct = _applyDCT(matrix);

      final values = <double>[];

      for (int y = 0; y < 8; y++) {
        for (int x = 0; x < 8; x++) {
          if (x == 0 && y == 0) {
            continue;
          }

          values.add(dct[y][x]);
        }
      }

      values.sort();

      final median = values[values.length ~/ 2];

      BigInt hash = BigInt.zero;

      int bit = 0;

      for (int y = 0; y < 8; y++) {
        for (int x = 0; x < 8; x++) {
          if (x == 0 && y == 0) {
            continue;
          }

          if (dct[y][x] > median) {
            hash |= (BigInt.one << bit);
          }

          bit++;
        }
      }

      return hash;
    } catch (_) {
      return null;
    }
  }

  List<List<double>> _applyDCT(List<List<double>> input) {
    const n = 32;

    final output = List.generate(n, (_) => List.filled(n, 0.0));

    for (int u = 0; u < n; u++) {
      for (int v = 0; v < n; v++) {
        double sum = 0;

        for (int x = 0; x < n; x++) {
          for (int y = 0; y < n; y++) {
            sum +=
                input[x][y] *
                math.cos(((2 * x + 1) * u * math.pi) / (2 * n)) *
                math.cos(((2 * y + 1) * v * math.pi) / (2 * n));
          }
        }

        final cu = u == 0 ? 1 / math.sqrt(2) : 1.0;

        final cv = v == 0 ? 1 / math.sqrt(2) : 1.0;

        output[u][v] = 0.25 * cu * cv * sum;
      }
    }

    return output;
  }

  int _hammingDistance(BigInt a, BigInt b) {
    BigInt xor = a ^ b;

    int count = 0;

    while (xor > BigInt.zero) {
      count += (xor & BigInt.one).toInt();

      xor >>= 1;
    }

    return count;
  }
}
