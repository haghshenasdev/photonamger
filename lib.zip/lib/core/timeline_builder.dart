import '../ui/models/media_item.dart';
import '../ui/models/timeline_group.dart';

class TimelineBuilder {

  List<TimelineGroup> build(
    List<MediaItem> items,
  ) {

    if (items.isEmpty) {
      return [];
    }

    const gapMinutes = 30;

    List<TimelineGroup> groups = [];

    List<MediaItem> current = [];

    current.add(items.first);

    for (
      int i = 1;
      i < items.length;
      i++
    ) {

      final previous =
          items[i - 1];

      final currentItem =
          items[i];

      final diff =
          currentItem.createdAt
              .difference(
                previous.createdAt,
              );

      if (
          diff.inMinutes >
          gapMinutes) {

        groups.add(
          _createGroup(
            groups.length + 1,
            current,
          ),
        );

        current = [];
      }

      current.add(currentItem);
    }

    if (current.isNotEmpty) {

      groups.add(
        _createGroup(
          groups.length + 1,
          current,
        ),
      );
    }

    return groups;
  }

  TimelineGroup _createGroup(
    int index,
    List<MediaItem> items,
  ) {

    return TimelineGroup(
      title: 'گروه $index',

      start:
          items.first.createdAt,

      end:
          items.last.createdAt,

      items: List.from(items),
    );
  }
}