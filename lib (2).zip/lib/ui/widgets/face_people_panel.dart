import 'dart:io';

import 'package:fluent_ui/fluent_ui.dart';

import '../../core/analysis/face_database.dart';

class FacePeoplePanel extends StatefulWidget {
  final FaceDatabase database;
  final List<String> sourceRoots;
  final String? selectedPersonId;
  final ValueChanged<String?> onPersonSelected;
  final Future<void> Function(String personId, String name)? onRename;

  const FacePeoplePanel({
    super.key,
    required this.database,
    required this.sourceRoots,
    required this.selectedPersonId,
    required this.onPersonSelected,
    this.onRename,
  });

  @override
  State<FacePeoplePanel> createState() => _FacePeoplePanelState();
}

class _FacePeoplePanelState extends State<FacePeoplePanel> {
  final TextEditingController _searchController = TextEditingController();

  String _query = '';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<FacePerson> get _persons {
    final query = _query.trim().toLowerCase();

    final counts = <String, int>{};
    for (final face in widget.database.faces) {
      counts.update(face.personId, (value) => value + 1, ifAbsent: () => 1);
    }

    final result = widget.database.persons.where((person) {
      if (query.isEmpty) return true;
      return person.name.toLowerCase().contains(query);
    }).toList();

    result.sort((a, b) {
      final countCompare =
          (counts[b.id] ?? 0).compareTo(counts[a.id] ?? 0);
      if (countCompare != 0) return countCompare;
      return a.name.compareTo(b.name);
    });

    return result;
  }

  String? _coverPath(FacePerson person) {
    final rootKey = person.coverRootKey;
    final relative = person.coverRelativePath;
    if (rootKey == null || relative == null) return null;

    for (final root in widget.sourceRoots) {
      if (FaceDatabaseService.normalizeRootKey(root) == rootKey) {
        return '${root.replaceAll('\\', '/')}/'
            '${relative.replaceAll('\\', '/')}';
      }
    }

    return null;
  }

  int _count(FacePerson person) {
    final keys = <String>{};
    for (final face in widget.database.faces) {
      if (face.personId == person.id) {
        keys.add('${face.rootKey}|${face.relativePath.toLowerCase()}');
      }
    }
    return keys.length;
  }

  Future<void> _rename(FacePerson person) async {
    if (widget.onRename == null) return;

    final controller = TextEditingController(text: person.name);

    final name = await showDialog<String>(
      context: context,
      builder: (context) {
        return ContentDialog(
          title: const Text('نام شخص'),
          content: TextBox(
            controller: controller,
            autofocus: true,
            placeholder: 'مثلاً مهدی',
            onSubmitted: (_) =>
                Navigator.of(context).pop(controller.text.trim()),
          ),
          actions: [
            Button(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('انصراف'),
            ),
            FilledButton(
              onPressed: () =>
                  Navigator.of(context).pop(controller.text.trim()),
              child: const Text('ذخیره'),
            ),
          ],
        );
      },
    );

    controller.dispose();

    if (name != null && name.trim().isNotEmpty) {
      await widget.onRename!(person.id, name.trim());
    }
  }

  @override
  Widget build(BuildContext context) {
    final persons = _persons;

    return Card(
      padding: const EdgeInsets.all(10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              const Icon(FluentIcons.contact, size: 18),
              const SizedBox(width: 8),
              const Expanded(
                child: Text(
                  'افراد',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
              ),
              Text(
                '${widget.database.persons.length}',
                style: TextStyle(
                  fontSize: 12,
                  color: FluentTheme.of(context).resources.textFillColorSecondary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          TextBox(
            controller: _searchController,
            placeholder: 'جستجوی نام شخص...',
            prefix: const Padding(
              padding: EdgeInsetsDirectional.only(start: 8),
              child: Icon(FluentIcons.search, size: 15),
            ),
            suffix: _query.isEmpty
                ? null
                : IconButton(
                    icon: const Icon(FluentIcons.clear, size: 12),
                    onPressed: () {
                      _searchController.clear();
                      setState(() => _query = '');
                    },
                  ),
            onChanged: (value) => setState(() => _query = value),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: persons.isEmpty
                ? Center(
                    child: Text(
                      _query.isEmpty
                          ? 'هنوز چهره‌ای دسته‌بندی نشده است.'
                          : 'موردی پیدا نشد.',
                      textAlign: TextAlign.center,
                    ),
                  )
                : ListView.separated(
                    itemCount: persons.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 5),
                    itemBuilder: (context, index) {
                      final person = persons[index];
                      final selected =
                          person.id == widget.selectedPersonId;
                      final cover = _coverPath(person);

                      return GestureDetector(
                        onDoubleTap: () => _rename(person),
                        child: HoverButton(
                          onPressed: () =>
                              widget.onPersonSelected(person.id),
                          builder: (context, states) {
                            return Container(
                              padding: const EdgeInsets.all(7),
                              decoration: BoxDecoration(
                                color: selected
                                    ? FluentTheme.of(context)
                                        .accentColor
                                        .withOpacity(0.12)
                                    : null,
                                borderRadius: BorderRadius.circular(7),
                                border: Border.all(
                                  color: selected
                                      ? FluentTheme.of(context).accentColor
                                      : Colors.transparent,
                                ),
                              ),
                              child: Row(
                                children: [
                                  _FaceAvatar(path: cover),
                                  const SizedBox(width: 9),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          person.name,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                        const SizedBox(height: 2),
                                        Text(
                                          '${_count(person)} تصویر',
                                          style: TextStyle(
                                            fontSize: 11,
                                            color: FluentTheme.of(context)
                                                .resources
                                                .textFillColorSecondary,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  IconButton(
                                    icon: const Icon(
                                      FluentIcons.edit,
                                      size: 13,
                                    ),
                                    onPressed: () => _rename(person),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      );
                    },
                  ),
          ),
          if (widget.selectedPersonId != null) ...[
            const SizedBox(height: 8),
            Button(
              onPressed: () => widget.onPersonSelected(null),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(FluentIcons.clear, size: 13),
                  SizedBox(width: 6),
                  Text('نمایش همه تصاویر'),
                ],
              ),
            ),
          ],
          const SizedBox(height: 4),
          Text(
            'دوبار کلیک روی نام برای تغییر نام',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 10,
              color: FluentTheme.of(context).resources.textFillColorTertiary,
            ),
          ),
        ],
      ),
    );
  }
}

class _FaceAvatar extends StatelessWidget {
  final String? path;

  const _FaceAvatar({this.path});

  @override
  Widget build(BuildContext context) {
    final file = path == null ? null : File(path!);

    return ClipRRect(
      borderRadius: BorderRadius.circular(7),
      child: SizedBox(
        width: 48,
        height: 48,
        child: file != null && file.existsSync()
            ? Image.file(file, fit: BoxFit.cover)
            : Container(
                color: FluentTheme.of(context)
                    .resources
                    .controlFillColorSecondary,
                child: const Icon(FluentIcons.contact, size: 21),
              ),
      ),
    );
  }
}
