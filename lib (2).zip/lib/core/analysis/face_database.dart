import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:path/path.dart' as p;

import '../../ui/models/media_item.dart';
import 'face_info.dart';

class FacePerson {
  String id;
  String name;
  String? coverRootKey;
  String? coverRelativePath;
  DateTime createdAt;
  DateTime updatedAt;

  FacePerson({
    required this.id,
    required this.name,
    this.coverRootKey,
    this.coverRelativePath,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) : createdAt = createdAt ?? DateTime.now(),
       updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'coverRootKey': coverRootKey,
    'coverRelativePath': coverRelativePath,
    'createdAt': createdAt.toIso8601String(),
    'updatedAt': updatedAt.toIso8601String(),
  };

  factory FacePerson.fromJson(Map<String, dynamic> json) {
    return FacePerson(
      id: json['id']?.toString() ?? '',
      name: json['name']?.toString() ?? 'شخص',
      coverRootKey: json['coverRootKey']?.toString(),
      coverRelativePath: json['coverRelativePath']?.toString(),
      createdAt: DateTime.tryParse(json['createdAt']?.toString() ?? ''),
      updatedAt: DateTime.tryParse(json['updatedAt']?.toString() ?? ''),
    );
  }
}

class StoredFace {
  String id;
  String personId;
  String rootKey;
  String relativePath;
  String fingerprint;
  double left;
  double top;
  double width;
  double height;
  double confidence;
  List<double> landmarks;
  List<double> embedding;

  StoredFace({
    required this.id,
    required this.personId,
    required this.rootKey,
    required this.relativePath,
    required this.fingerprint,
    required this.left,
    required this.top,
    required this.width,
    required this.height,
    required this.confidence,
    required this.landmarks,
    required this.embedding,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'personId': personId,
    'rootKey': rootKey,
    'relativePath': relativePath,
    'fingerprint': fingerprint,
    'box': [left, top, width, height],
    'confidence': confidence,
    'landmarks': landmarks,
    // Float32 base64 keeps the portable JSON much smaller than 128
    // decimal numbers per face.
    'embedding': base64UrlEncode(
      Float32List.fromList(embedding).buffer.asUint8List(),
    ),
  };

  factory StoredFace.fromJson(Map<String, dynamic> json) {
    final box = json['box'] is List
        ? (json['box'] as List).map((e) => double.tryParse('$e') ?? 0).toList()
        : const <double>[];

    final landmarks = json['landmarks'] is List
        ? (json['landmarks'] as List)
              .map((e) => double.tryParse('$e') ?? 0)
              .toList()
        : <double>[];

    List<double> embedding;
    final rawEmbedding = json['embedding'];
    if (rawEmbedding is String && rawEmbedding.isNotEmpty) {
      try {
        final bytes = base64Url.decode(rawEmbedding);
        final floats = Float32List.view(Uint8List.fromList(bytes).buffer);
        embedding = floats.map((e) => e.toDouble()).toList();
      } catch (_) {
        embedding = <double>[];
      }
    } else if (rawEmbedding is List) {
      // Backward compatibility with the first JSON format.
      embedding = rawEmbedding.map((e) => double.tryParse('$e') ?? 0).toList();
    } else {
      embedding = <double>[];
    }

    return StoredFace(
      id: json['id']?.toString() ?? '',
      personId: json['personId']?.toString() ?? '',
      rootKey: json['rootKey']?.toString() ?? '',
      relativePath: json['relativePath']?.toString() ?? '',
      fingerprint: json['fingerprint']?.toString() ?? '',
      left: box.length > 0 ? box[0] : 0,
      top: box.length > 1 ? box[1] : 0,
      width: box.length > 2 ? box[2] : 0,
      height: box.length > 3 ? box[3] : 0,
      confidence: double.tryParse('${json['confidence']}') ?? 0,
      landmarks: landmarks,
      embedding: embedding,
    );
  }
}

/// Portable face database.
///
/// The database intentionally stores paths relative to a source root, not
/// absolute file paths. The database can therefore move together with the
/// project/source folder.
class FaceScan {
  String rootKey;
  String relativePath;
  String fingerprint;

  FaceScan({
    required this.rootKey,
    required this.relativePath,
    required this.fingerprint,
  });

  Map<String, dynamic> toJson() => {
    'rootKey': rootKey,
    'relativePath': relativePath,
    'fingerprint': fingerprint,
  };

  factory FaceScan.fromJson(Map<String, dynamic> json) => FaceScan(
    rootKey: json['rootKey']?.toString() ?? '',
    relativePath: json['relativePath']?.toString() ?? '',
    fingerprint: json['fingerprint']?.toString() ?? '',
  );
}

class FaceDatabase {
  int version = 1;
  List<FacePerson> persons;
  List<StoredFace> faces;
  List<FaceScan> scans;

  FaceDatabase({
    List<FacePerson>? persons,
    List<StoredFace>? faces,
    List<FaceScan>? scans,
  }) : persons = persons ?? <FacePerson>[],
       faces = faces ?? <StoredFace>[],
       scans = scans ?? <FaceScan>[];

  Map<String, dynamic> toJson() => {
    'version': version,
    'persons': persons.map((e) => e.toJson()).toList(),
    'faces': faces.map((e) => e.toJson()).toList(),
    'scans': scans.map((e) => e.toJson()).toList(),
  };

  String toPrettyJson() => const JsonEncoder.withIndent('  ').convert(toJson());

  factory FaceDatabase.fromJson(Map<String, dynamic> json) {
    final persons = <FacePerson>[];
    final rawPersons = json['persons'];
    if (rawPersons is List) {
      for (final raw in rawPersons) {
        if (raw is Map) {
          persons.add(FacePerson.fromJson(Map<String, dynamic>.from(raw)));
        }
      }
    }

    final scans = <FaceScan>[];
    final rawScans = json['scans'];
    if (rawScans is List) {
      for (final raw in rawScans) {
        if (raw is Map) {
          scans.add(FaceScan.fromJson(Map<String, dynamic>.from(raw)));
        }
      }
    }

    final faces = <StoredFace>[];
    final rawFaces = json['faces'];
    if (rawFaces is List) {
      for (final raw in rawFaces) {
        if (raw is Map) {
          faces.add(StoredFace.fromJson(Map<String, dynamic>.from(raw)));
        }
      }
    }

    return FaceDatabase(persons: persons, faces: faces, scans: scans)
      ..version = int.tryParse('${json['version']}') ?? 1;
  }
}

class FaceDatabaseService {
  static const fileName = '.archino_faces.json';
  static const recognitionThreshold = 0.55;

  const FaceDatabaseService();

  File fileFor(String baseDirectory) => File(p.join(baseDirectory, fileName));

  Future<FaceDatabase> load(String baseDirectory) async {
    final file = fileFor(baseDirectory);
    if (!await file.exists()) return FaceDatabase();

    final candidates = <File>[
      if (await file.exists()) file,
      File('${file.path}.bak'),
      File('${file.path}.tmp'),
    ];

    for (final candidate in candidates) {
      if (!await candidate.exists()) continue;
      try {
        final text = await candidate.readAsString();
        final decoded = jsonDecode(text);
        if (decoded is Map) {
          return FaceDatabase.fromJson(Map<String, dynamic>.from(decoded));
        }
      } catch (_) {
        // Try the next recovery candidate.
      }
    }

    return FaceDatabase();
  }

  Future<void> save(String baseDirectory, FaceDatabase database) async {
    final directory = Directory(baseDirectory);
    await directory.create(recursive: true);

    final file = fileFor(baseDirectory);
    final temp = File('${file.path}.tmp');
    final backup = File('${file.path}.bak');

    await temp.writeAsString(
      database.toPrettyJson(),
      encoding: utf8,
      flush: true,
    );

    await file.parent.create(recursive: true);

    if (await backup.exists()) {
      await backup.delete();
    }

    if (await file.exists()) {
      await file.rename(backup.path);
    }

    try {
      await temp.rename(file.path);
      if (await backup.exists()) {
        await backup.delete();
      }
    } catch (_) {
      if (await file.exists()) {
        await file.delete();
      }
      if (await backup.exists()) {
        await backup.rename(file.path);
      }
      rethrow;
    }
  }

  /// Applies cached faces to scanned MediaItems.
  /// Returns the set of items that still need face inference.
  Future<List<MediaItem>> applyCachedFaces({
    required String databaseDirectory,
    required List<String> sourceRoots,
    required List<MediaItem> items,
  }) async {
    final db = await load(databaseDirectory);

    var databaseChanged = false;

    final pending = <MediaItem>[];

    // ------------------------------------------------------------
    // Exact lookup
    //
    // root + relativePath + fingerprint
    // ------------------------------------------------------------
    final byKey = <String, List<StoredFace>>{};

    // ------------------------------------------------------------
    // Portable lookup
    //
    // filename + fingerprint
    //
    // این lookup برای زمانی است که:
    // - پوشه جابه‌جا شده
    // - Root تغییر کرده
    // - مسیر نسبی تغییر کرده
    // ------------------------------------------------------------
    final byPortableKey = <String, List<StoredFace>>{};

    for (final face in db.faces) {
      final exactKey =
          '${face.rootKey}|'
          '${_normRelative(face.relativePath)}|'
          '${face.fingerprint}';

      byKey.putIfAbsent(exactKey, () => []).add(face);

      final fileName = p.basename(_normRelative(face.relativePath));

      final portableKey = '$fileName|${face.fingerprint}';

      byPortableKey.putIfAbsent(portableKey, () => []).add(face);
    }

    // ------------------------------------------------------------
    // Process current media
    // ------------------------------------------------------------
    for (final item in items) {
      item.faces = [];

      // Videoها را فعلاً وارد Face Recognition نمی‌کنیم.
      if (item.isVideo) {
        continue;
      }

      final location = _locate(item.path, sourceRoots);

      if (location == null) {
        pending.add(item);
        continue;
      }

      final fingerprint = await fingerprintOf(item.path);

      final normalizedRelative = _normRelative(location.relativePath);

      final exactKey =
          '${location.rootKey}|'
          '$normalizedRelative|'
          '$fingerprint';

      List<StoredFace>? cached = byKey[exactKey];

      // ==========================================================
      // Exact match پیدا نشد.
      //
      // حالا filename + fingerprint را امتحان می‌کنیم.
      // ==========================================================
      if (cached == null || cached.isEmpty) {
        final portableKey = '${p.basename(normalizedRelative)}|$fingerprint';

        final portableMatches = byPortableKey[portableKey];

        if (portableMatches != null && portableMatches.isNotEmpty) {
          cached = List<StoredFace>.from(portableMatches);

          // ------------------------------------------------------
          // اگر عکس جابه‌جا شده باشد، اطلاعات ذخیره‌شده را
          // به مسیر جدید rebase می‌کنیم.
          // ------------------------------------------------------
          for (final face in cached) {
            face.rootKey = location.rootKey;
            face.relativePath = location.relativePath;
            face.fingerprint = fingerprint;
          }

          databaseChanged = true;

          // ------------------------------------------------------
          // lookup دقیق را هم به‌روزرسانی می‌کنیم تا اگر چند بار
          // در همین session به این فایل رسیدیم، دوباره lookup
          // portable انجام نشود.
          // ------------------------------------------------------
          byKey[exactKey] = cached;
        }
      }

      // ==========================================================
      // آیا این فایل قبلاً scan شده؟
      // ==========================================================
      final hasScan = db.scans.any(
        (scan) =>
            scan.rootKey == location.rootKey &&
            _normRelative(scan.relativePath) == normalizedRelative &&
            scan.fingerprint == fingerprint,
      );

      // ==========================================================
      // هیچ اطلاعات Face نداریم
      // ==========================================================
      if (cached == null || cached.isEmpty) {
        if (!hasScan) {
          pending.add(item);
        }

        continue;
      }

      // ==========================================================
      // اگر scan فعلی وجود ندارد، آن را ثبت کن.
      // ==========================================================
      if (!hasScan) {
        db.scans.removeWhere(
          (scan) =>
              scan.fingerprint == fingerprint &&
              p.basename(_normRelative(scan.relativePath)) ==
                  p.basename(normalizedRelative),
        );

        db.scans.add(
          FaceScan(
            rootKey: location.rootKey,
            relativePath: location.relativePath,
            fingerprint: fingerprint,
          ),
        );

        databaseChanged = true;
      }

      // ==========================================================
      // انتقال StoredFace -> FaceInfo
      // ==========================================================
      item.faces = cached.map((face) {
        return FaceInfo(
          left: face.left,
          top: face.top,
          width: face.width,
          height: face.height,
          landmarks: List<double>.from(face.landmarks),
          confidence: face.confidence,
          embedding: List<double>.from(face.embedding),
          personId: face.personId,
          faceArea: face.width * face.height,
        );
      }).toList();

      item.faceCount = item.faces.length;
    }

    // ============================================================
    // Save only when something actually changed.
    // ============================================================
    if (databaseChanged) {
      await save(databaseDirectory, db);
    }

    return pending;
  }

  /// Adds new faces and automatically assigns each face to the closest
  /// existing person. A new person is created only when similarity is below
  /// the conservative threshold.
  Future<void> mergeAnalysis({
    required String databaseDirectory,
    required List<String> sourceRoots,
    required Map<MediaItem, List<FaceInfo>> analyzed,
  }) async {
    final db = await load(databaseDirectory);

    final existingByFile = <String, List<StoredFace>>{};
    for (final face in db.faces) {
      existingByFile
          .putIfAbsent(
            '${face.rootKey}|${_normRelative(face.relativePath)}',
            () => [],
          )
          .add(face);
    }

    final prototypes = _buildPrototypes(db);

    for (final entry in analyzed.entries) {
      final item = entry.key;
      final location = _locate(item.path, sourceRoots);
      if (location == null) continue;

      final fingerprint = await fingerprintOf(item.path);
      final fileKey =
          '${location.rootKey}|${_normRelative(location.relativePath)}';

      // Replace old records for this file. This also handles edited/replaced
      // images without leaving stale identities behind.
      db.faces.removeWhere(
        (face) =>
            '${face.rootKey}|${_normRelative(face.relativePath)}' == fileKey,
      );
      db.scans.removeWhere(
        (scan) =>
            '${scan.rootKey}|${_normRelative(scan.relativePath)}' == fileKey,
      );
      db.scans.add(
        FaceScan(
          rootKey: location.rootKey,
          relativePath: location.relativePath,
          fingerprint: fingerprint,
        ),
      );

      item.faces = [];

      for (final detected in entry.value) {
        if (detected.embedding.length < 8) continue;

        final normalized = _normalize(detected.embedding);
        final match = _findPerson(normalized, prototypes, db);

        final person = match ?? _createPerson(db);

        final stored = StoredFace(
          id: _newId(),
          personId: person.id,
          rootKey: location.rootKey,
          relativePath: location.relativePath,
          fingerprint: fingerprint,
          left: detected.left,
          top: detected.top,
          width: detected.width,
          height: detected.height,
          confidence: detected.confidence,
          landmarks: List<double>.from(detected.landmarks),
          embedding: normalized,
        );

        db.faces.add(stored);
        prototypes[person.id] = _blend(prototypes[person.id], normalized);

        item.faces.add(
          detected.copyWith(embedding: normalized, personId: person.id),
        );

        if (person.coverRelativePath == null || detected.quality > 0.75) {
          person.coverRootKey = location.rootKey;
          person.coverRelativePath = location.relativePath;
        }
        person.updatedAt = DateTime.now();
      }

      item.faceCount = item.faces.length;
    }

    // Remove faces whose image no longer exists in the current scan.
    final liveKeys = <String>{};
    for (final item in analyzed.keys) {
      final location = _locate(item.path, sourceRoots);
      if (location != null) {
        liveKeys.add(
          '${location.rootKey}|${_normRelative(location.relativePath)}',
        );
      }
    }

    // Do not prune the entire DB here: analyzed may contain only changed
    // files. The normal scan cleanup is deliberately conservative.
    await save(databaseDirectory, db);
  }

  Future<void> renamePerson({
    required String databaseDirectory,
    required String personId,
    required String name,
  }) async {
    final db = await load(databaseDirectory);
    FacePerson? person;
    for (final candidate in db.persons) {
      if (candidate.id == personId) {
        person = candidate;
        break;
      }
    }
    if (person == null) return;

    person.name = name.trim().isEmpty ? 'شخص' : name.trim();
    person.updatedAt = DateTime.now();
    await save(databaseDirectory, db);
  }

  Future<FaceDatabase> loadForUi(String databaseDirectory) =>
      load(databaseDirectory);

  String resolveStoredPath(StoredFace face, List<String> sourceRoots) {
    for (final root in sourceRoots) {
      if (_rootKey(root) == face.rootKey) {
        return p.join(root, face.relativePath);
      }
    }
    return p.join(
      sourceRoots.isEmpty ? '' : sourceRoots.first,
      face.relativePath,
    );
  }

  static Future<String> fingerprintOf(String path) async {
    try {
      final stat = await File(path).stat();
      return '${stat.size}:${stat.modified.microsecondsSinceEpoch}';
    } catch (_) {
      return 'missing';
    }
  }

  Map<String, List<double>> _buildPrototypes(FaceDatabase db) {
    final grouped = <String, List<List<double>>>{};

    for (final face in db.faces) {
      if (face.embedding.length < 8) continue;
      grouped.putIfAbsent(face.personId, () => []).add(face.embedding);
    }

    final result = <String, List<double>>{};
    for (final entry in grouped.entries) {
      // A compact prototype is much faster than comparing every historical
      // face. The mean is re-normalized after each update.
      final dim = entry.value.first.length;
      final mean = List<double>.filled(dim, 0);
      for (final vector in entry.value) {
        for (var i = 0; i < dim && i < vector.length; i++) {
          mean[i] += vector[i];
        }
      }
      for (var i = 0; i < mean.length; i++) {
        mean[i] /= entry.value.length;
      }
      result[entry.key] = _normalize(mean);
    }

    return result;
  }

  FacePerson? _findPerson(
    List<double> embedding,
    Map<String, List<double>> prototypes,
    FaceDatabase db,
  ) {
    FacePerson? best;
    var bestScore = -1.0;

    // The prototype map only contains person ids. The actual person object
    // is loaded separately by _findPersonName below.
    for (final entry in prototypes.entries) {
      final score = cosine(embedding, entry.value);
      if (score > bestScore) {
        bestScore = score;
        for (final person in db.persons) {
          if (person.id == entry.key) {
            best = person;
            break;
          }
        }
      }
    }

    return bestScore >= recognitionThreshold ? best : null;
  }

  FacePerson _createPerson(FaceDatabase db) {
    final index = db.persons.length + 1;
    final person = FacePerson(id: _newId(), name: 'شخص $index');
    db.persons.add(person);
    return person;
  }

  static List<double> _blend(List<double>? old, List<double> next) {
    if (old == null || old.length != next.length) {
      return List<double>.from(next);
    }

    final result = List<double>.generate(
      next.length,
      (i) => old[i] * 0.75 + next[i] * 0.25,
    );
    return _normalize(result);
  }

  static List<double> _normalize(List<double> vector) {
    var sum = 0.0;
    for (final value in vector) {
      sum += value * value;
    }
    final norm = math.sqrt(sum);
    if (norm <= 1e-9) return List<double>.from(vector);
    return vector.map((e) => e / norm).toList();
  }

  static double cosine(List<double> a, List<double> b) {
    final length = math.min(a.length, b.length);
    var dot = 0.0;
    for (var i = 0; i < length; i++) {
      dot += a[i] * b[i];
    }
    return dot;
  }

  static String _newId() =>
      '${DateTime.now().microsecondsSinceEpoch}_${math.Random().nextInt(1 << 20)}';

  static String normalizeRootKey(String root) => _rootKey(root);

  static String _rootKey(String root) {
    var value = p.basename(p.normalize(root)).trim();
    if (value.isEmpty) value = 'root';
    return Platform.isWindows ? value.toLowerCase() : value;
  }

  static String _normRelative(String value) => value
      .replaceAll('\\', '/')
      .replaceFirst(RegExp(r'^/+'), '')
      .toLowerCase();

  _FaceLocation? _locate(String filePath, List<String> roots) {
    final normalizedFile = p.normalize(filePath);

    for (final root in roots) {
      final normalizedRoot = p.normalize(root);
      final relative = p.relative(normalizedFile, from: normalizedRoot);

      if (relative == normalizedFile ||
          relative.startsWith('..${p.separator}')) {
        continue;
      }

      return _FaceLocation(rootKey: _rootKey(root), relativePath: relative);
    }

    return null;
  }
}

class _FaceLocation {
  final String rootKey;
  final String relativePath;

  const _FaceLocation({required this.rootKey, required this.relativePath});
}
